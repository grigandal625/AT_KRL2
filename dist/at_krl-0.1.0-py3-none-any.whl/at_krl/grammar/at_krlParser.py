# Generated from /app/at_krl.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,84,498,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,1,0,1,0,1,1,1,1,1,2,1,2,
        1,3,1,3,1,4,1,4,1,4,1,4,1,5,5,5,102,8,5,10,5,12,5,105,9,5,1,6,5,
        6,108,8,6,10,6,12,6,111,9,6,1,7,5,7,114,8,7,10,7,12,7,117,9,7,1,
        8,1,8,4,8,121,8,8,11,8,12,8,122,1,9,1,9,1,10,1,10,1,10,1,10,1,10,
        3,10,132,8,10,1,10,1,10,1,10,1,10,1,10,3,10,139,8,10,3,10,141,8,
        10,1,11,1,11,1,11,1,11,1,11,3,11,148,8,11,1,11,3,11,151,8,11,1,12,
        1,12,4,12,155,8,12,11,12,12,12,156,1,13,1,13,1,13,1,14,1,14,4,14,
        164,8,14,11,14,12,14,165,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,16,
        1,16,1,16,1,17,1,17,1,17,1,17,1,17,3,17,183,8,17,1,18,1,18,1,18,
        1,18,1,18,1,18,3,18,191,8,18,1,18,1,18,1,18,1,18,1,18,3,18,198,8,
        18,1,18,1,18,1,18,1,18,1,18,3,18,205,8,18,1,18,1,18,1,18,1,18,1,
        18,3,18,212,8,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,
        18,3,18,224,8,18,1,18,3,18,227,8,18,1,18,1,18,1,18,1,18,1,18,3,18,
        234,8,18,1,18,1,18,1,18,1,18,1,18,3,18,241,8,18,1,18,1,18,1,18,1,
        18,1,18,3,18,248,8,18,1,18,1,18,1,18,1,18,1,18,3,18,255,8,18,5,18,
        257,8,18,10,18,12,18,260,9,18,1,19,1,19,1,19,1,19,1,20,1,20,1,20,
        1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,
        1,20,1,20,1,20,1,20,1,20,3,20,287,8,20,1,20,1,20,1,20,1,20,1,20,
        3,20,294,8,20,1,20,1,20,1,20,1,20,1,20,3,20,301,8,20,1,20,1,20,1,
        20,1,20,1,20,3,20,308,8,20,1,20,1,20,1,20,1,20,1,20,3,20,315,8,20,
        5,20,317,8,20,10,20,12,20,320,9,20,1,21,1,21,1,22,1,22,1,23,1,23,
        1,23,1,23,1,23,1,23,3,23,332,8,23,1,24,1,24,1,24,3,24,337,8,24,1,
        25,1,25,1,26,1,26,1,26,1,26,3,26,345,8,26,1,26,1,26,1,26,3,26,350,
        8,26,1,27,1,27,1,28,1,28,1,28,1,28,3,28,358,8,28,1,29,3,29,361,8,
        29,1,29,1,29,1,29,3,29,366,8,29,1,30,1,30,4,30,370,8,30,11,30,12,
        30,371,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,382,8,31,1,31,
        1,31,1,31,3,31,387,8,31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,395,8,
        31,1,32,1,32,1,32,4,32,400,8,32,11,32,12,32,401,1,33,1,33,1,33,1,
        34,1,34,1,34,1,34,3,34,411,8,34,1,34,3,34,414,8,34,1,35,1,35,1,35,
        1,35,1,36,1,36,1,36,1,36,5,36,424,8,36,10,36,12,36,427,9,36,1,36,
        3,36,430,8,36,1,36,1,36,1,37,1,37,1,37,1,37,3,37,438,8,37,1,38,1,
        38,1,38,3,38,443,8,38,1,39,1,39,1,39,3,39,448,8,39,1,39,1,39,1,39,
        1,39,1,39,3,39,455,8,39,1,40,1,40,1,40,3,40,460,8,40,1,40,1,40,1,
        40,1,40,1,40,1,40,1,40,1,40,1,40,3,40,471,8,40,1,41,1,41,3,41,475,
        8,41,1,41,1,41,1,42,3,42,480,8,42,1,42,4,42,483,8,42,11,42,12,42,
        484,1,43,1,43,1,43,1,43,1,43,1,43,3,43,493,8,43,1,43,3,43,496,8,
        43,1,43,8,103,109,115,122,371,401,425,484,2,36,40,44,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,
        56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,0,13,1,0,1,10,1,
        0,11,23,1,0,24,27,1,0,28,36,2,0,12,12,37,38,1,0,79,80,2,0,78,78,
        81,81,1,0,40,41,2,0,7,9,26,26,1,0,7,9,3,0,78,78,81,81,84,84,1,0,
        59,60,1,0,57,58,534,0,88,1,0,0,0,2,90,1,0,0,0,4,92,1,0,0,0,6,94,
        1,0,0,0,8,96,1,0,0,0,10,103,1,0,0,0,12,109,1,0,0,0,14,115,1,0,0,
        0,16,118,1,0,0,0,18,124,1,0,0,0,20,140,1,0,0,0,22,142,1,0,0,0,24,
        152,1,0,0,0,26,158,1,0,0,0,28,161,1,0,0,0,30,167,1,0,0,0,32,174,
        1,0,0,0,34,182,1,0,0,0,36,226,1,0,0,0,38,261,1,0,0,0,40,286,1,0,
        0,0,42,321,1,0,0,0,44,323,1,0,0,0,46,331,1,0,0,0,48,333,1,0,0,0,
        50,338,1,0,0,0,52,349,1,0,0,0,54,351,1,0,0,0,56,353,1,0,0,0,58,365,
        1,0,0,0,60,367,1,0,0,0,62,373,1,0,0,0,64,396,1,0,0,0,66,403,1,0,
        0,0,68,406,1,0,0,0,70,415,1,0,0,0,72,419,1,0,0,0,74,433,1,0,0,0,
        76,442,1,0,0,0,78,444,1,0,0,0,80,456,1,0,0,0,82,474,1,0,0,0,84,479,
        1,0,0,0,86,486,1,0,0,0,88,89,7,0,0,0,89,1,1,0,0,0,90,91,7,1,0,0,
        91,3,1,0,0,0,92,93,7,2,0,0,93,5,1,0,0,0,94,95,7,3,0,0,95,7,1,0,0,
        0,96,97,3,10,5,0,97,98,3,12,6,0,98,99,3,14,7,0,99,9,1,0,0,0,100,
        102,3,56,28,0,101,100,1,0,0,0,102,105,1,0,0,0,103,104,1,0,0,0,103,
        101,1,0,0,0,104,11,1,0,0,0,105,103,1,0,0,0,106,108,3,74,37,0,107,
        106,1,0,0,0,108,111,1,0,0,0,109,110,1,0,0,0,109,107,1,0,0,0,110,
        13,1,0,0,0,111,109,1,0,0,0,112,114,3,22,11,0,113,112,1,0,0,0,114,
        117,1,0,0,0,115,116,1,0,0,0,115,113,1,0,0,0,116,15,1,0,0,0,117,115,
        1,0,0,0,118,120,5,55,0,0,119,121,9,0,0,0,120,119,1,0,0,0,121,122,
        1,0,0,0,122,123,1,0,0,0,122,120,1,0,0,0,123,17,1,0,0,0,124,125,3,
        20,10,0,125,19,1,0,0,0,126,127,3,48,24,0,127,128,7,4,0,0,128,131,
        3,54,27,0,129,132,3,34,17,0,130,132,1,0,0,0,131,129,1,0,0,0,131,
        130,1,0,0,0,132,141,1,0,0,0,133,134,3,54,27,0,134,135,5,39,0,0,135,
        138,3,48,24,0,136,139,3,34,17,0,137,139,1,0,0,0,138,136,1,0,0,0,
        138,137,1,0,0,0,139,141,1,0,0,0,140,126,1,0,0,0,140,133,1,0,0,0,
        141,21,1,0,0,0,142,143,5,46,0,0,143,144,7,5,0,0,144,145,3,26,13,
        0,145,147,3,24,12,0,146,148,3,28,14,0,147,146,1,0,0,0,147,148,1,
        0,0,0,148,150,1,0,0,0,149,151,3,16,8,0,150,149,1,0,0,0,150,151,1,
        0,0,0,151,23,1,0,0,0,152,154,5,48,0,0,153,155,3,18,9,0,154,153,1,
        0,0,0,155,156,1,0,0,0,156,154,1,0,0,0,156,157,1,0,0,0,157,25,1,0,
        0,0,158,159,5,47,0,0,159,160,3,36,18,0,160,27,1,0,0,0,161,163,5,
        49,0,0,162,164,3,18,9,0,163,162,1,0,0,0,164,165,1,0,0,0,165,163,
        1,0,0,0,165,166,1,0,0,0,166,29,1,0,0,0,167,168,5,44,0,0,168,169,
        5,73,0,0,169,170,7,6,0,0,170,171,7,7,0,0,171,172,7,6,0,0,172,173,
        5,74,0,0,173,31,1,0,0,0,174,175,5,45,0,0,175,176,7,6,0,0,176,33,
        1,0,0,0,177,178,3,30,15,0,178,179,3,32,16,0,179,183,1,0,0,0,180,
        183,3,30,15,0,181,183,3,32,16,0,182,177,1,0,0,0,182,180,1,0,0,0,
        182,181,1,0,0,0,183,35,1,0,0,0,184,185,6,18,-1,0,185,186,3,48,24,
        0,186,187,5,12,0,0,187,190,3,46,23,0,188,191,3,34,17,0,189,191,1,
        0,0,0,190,188,1,0,0,0,190,189,1,0,0,0,191,227,1,0,0,0,192,193,3,
        46,23,0,193,194,5,12,0,0,194,197,3,48,24,0,195,198,3,34,17,0,196,
        198,1,0,0,0,197,195,1,0,0,0,197,196,1,0,0,0,198,227,1,0,0,0,199,
        200,3,48,24,0,200,201,5,12,0,0,201,204,3,48,24,0,202,205,3,34,17,
        0,203,205,1,0,0,0,204,202,1,0,0,0,204,203,1,0,0,0,205,227,1,0,0,
        0,206,207,3,46,23,0,207,208,5,12,0,0,208,211,3,46,23,0,209,212,3,
        34,17,0,210,212,1,0,0,0,211,209,1,0,0,0,211,210,1,0,0,0,212,227,
        1,0,0,0,213,227,3,52,26,0,214,227,3,46,23,0,215,216,5,71,0,0,216,
        217,3,36,18,0,217,218,5,72,0,0,218,227,1,0,0,0,219,220,7,8,0,0,220,
        223,3,36,18,0,221,224,3,34,17,0,222,224,1,0,0,0,223,221,1,0,0,0,
        223,222,1,0,0,0,224,227,1,0,0,0,225,227,3,38,19,0,226,184,1,0,0,
        0,226,192,1,0,0,0,226,199,1,0,0,0,226,206,1,0,0,0,226,213,1,0,0,
        0,226,214,1,0,0,0,226,215,1,0,0,0,226,219,1,0,0,0,226,225,1,0,0,
        0,227,258,1,0,0,0,228,229,10,5,0,0,229,230,3,6,3,0,230,233,3,36,
        18,0,231,234,3,34,17,0,232,234,1,0,0,0,233,231,1,0,0,0,233,232,1,
        0,0,0,234,257,1,0,0,0,235,236,10,4,0,0,236,237,3,4,2,0,237,240,3,
        36,18,0,238,241,3,34,17,0,239,241,1,0,0,0,240,238,1,0,0,0,240,239,
        1,0,0,0,241,257,1,0,0,0,242,243,10,3,0,0,243,244,3,2,1,0,244,247,
        3,36,18,0,245,248,3,34,17,0,246,248,1,0,0,0,247,245,1,0,0,0,247,
        246,1,0,0,0,248,257,1,0,0,0,249,250,10,2,0,0,250,251,3,0,0,0,251,
        254,3,36,18,0,252,255,3,34,17,0,253,255,1,0,0,0,254,252,1,0,0,0,
        254,253,1,0,0,0,255,257,1,0,0,0,256,228,1,0,0,0,256,235,1,0,0,0,
        256,242,1,0,0,0,256,249,1,0,0,0,257,260,1,0,0,0,258,256,1,0,0,0,
        258,259,1,0,0,0,259,37,1,0,0,0,260,258,1,0,0,0,261,262,7,5,0,0,262,
        263,5,42,0,0,263,264,7,5,0,0,264,39,1,0,0,0,265,266,6,20,-1,0,266,
        267,3,44,22,0,267,268,5,12,0,0,268,269,3,48,24,0,269,287,1,0,0,0,
        270,271,3,48,24,0,271,272,5,12,0,0,272,273,3,48,24,0,273,287,1,0,
        0,0,274,275,3,48,24,0,275,276,5,12,0,0,276,277,3,44,22,0,277,287,
        1,0,0,0,278,287,3,50,25,0,279,287,3,44,22,0,280,281,7,9,0,0,281,
        287,3,40,20,6,282,283,5,71,0,0,283,284,3,40,20,0,284,285,5,72,0,
        0,285,287,1,0,0,0,286,265,1,0,0,0,286,270,1,0,0,0,286,274,1,0,0,
        0,286,278,1,0,0,0,286,279,1,0,0,0,286,280,1,0,0,0,286,282,1,0,0,
        0,287,318,1,0,0,0,288,289,10,5,0,0,289,290,3,6,3,0,290,293,3,40,
        20,0,291,294,3,34,17,0,292,294,1,0,0,0,293,291,1,0,0,0,293,292,1,
        0,0,0,294,317,1,0,0,0,295,296,10,4,0,0,296,297,3,4,2,0,297,300,3,
        40,20,0,298,301,3,34,17,0,299,301,1,0,0,0,300,298,1,0,0,0,300,299,
        1,0,0,0,301,317,1,0,0,0,302,303,10,3,0,0,303,304,3,2,1,0,304,307,
        3,40,20,0,305,308,3,34,17,0,306,308,1,0,0,0,307,305,1,0,0,0,307,
        306,1,0,0,0,308,317,1,0,0,0,309,310,10,2,0,0,310,311,3,0,0,0,311,
        314,3,40,20,0,312,315,3,34,17,0,313,315,1,0,0,0,314,312,1,0,0,0,
        314,313,1,0,0,0,315,317,1,0,0,0,316,288,1,0,0,0,316,295,1,0,0,0,
        316,302,1,0,0,0,316,309,1,0,0,0,317,320,1,0,0,0,318,316,1,0,0,0,
        318,319,1,0,0,0,319,41,1,0,0,0,320,318,1,0,0,0,321,322,3,40,20,0,
        322,43,1,0,0,0,323,324,7,10,0,0,324,45,1,0,0,0,325,326,5,71,0,0,
        326,327,3,46,23,0,327,328,3,34,17,0,328,329,5,72,0,0,329,332,1,0,
        0,0,330,332,3,44,22,0,331,325,1,0,0,0,331,330,1,0,0,0,332,47,1,0,
        0,0,333,336,7,5,0,0,334,335,5,70,0,0,335,337,3,48,24,0,336,334,1,
        0,0,0,336,337,1,0,0,0,337,49,1,0,0,0,338,339,3,48,24,0,339,51,1,
        0,0,0,340,341,5,71,0,0,341,344,3,50,25,0,342,345,3,34,17,0,343,345,
        1,0,0,0,344,342,1,0,0,0,344,343,1,0,0,0,345,346,1,0,0,0,346,347,
        5,72,0,0,347,350,1,0,0,0,348,350,3,50,25,0,349,340,1,0,0,0,349,348,
        1,0,0,0,350,53,1,0,0,0,351,352,3,36,18,0,352,55,1,0,0,0,353,354,
        5,50,0,0,354,355,7,5,0,0,355,357,3,58,29,0,356,358,3,16,8,0,357,
        356,1,0,0,0,357,358,1,0,0,0,358,57,1,0,0,0,359,361,3,60,30,0,360,
        359,1,0,0,0,360,361,1,0,0,0,361,362,1,0,0,0,362,366,3,64,32,0,363,
        366,3,60,30,0,364,366,3,62,31,0,365,360,1,0,0,0,365,363,1,0,0,0,
        365,364,1,0,0,0,366,59,1,0,0,0,367,369,5,65,0,0,368,370,5,84,0,0,
        369,368,1,0,0,0,370,371,1,0,0,0,371,372,1,0,0,0,371,369,1,0,0,0,
        372,61,1,0,0,0,373,374,5,66,0,0,374,381,5,68,0,0,375,382,5,78,0,
        0,376,382,5,81,0,0,377,378,5,26,0,0,378,382,5,78,0,0,379,380,5,26,
        0,0,380,382,5,81,0,0,381,375,1,0,0,0,381,376,1,0,0,0,381,377,1,0,
        0,0,381,379,1,0,0,0,382,383,1,0,0,0,383,386,5,69,0,0,384,387,5,26,
        0,0,385,387,1,0,0,0,386,384,1,0,0,0,386,385,1,0,0,0,387,394,1,0,
        0,0,388,395,5,78,0,0,389,395,5,81,0,0,390,391,5,26,0,0,391,395,5,
        78,0,0,392,393,5,26,0,0,393,395,5,81,0,0,394,388,1,0,0,0,394,389,
        1,0,0,0,394,390,1,0,0,0,394,392,1,0,0,0,395,63,1,0,0,0,396,397,5,
        67,0,0,397,399,5,78,0,0,398,400,3,66,33,0,399,398,1,0,0,0,400,401,
        1,0,0,0,401,402,1,0,0,0,401,399,1,0,0,0,402,65,1,0,0,0,403,404,3,
        68,34,0,404,405,3,72,36,0,405,67,1,0,0,0,406,407,5,84,0,0,407,408,
        7,6,0,0,408,410,7,6,0,0,409,411,5,78,0,0,410,409,1,0,0,0,410,411,
        1,0,0,0,411,413,1,0,0,0,412,414,5,12,0,0,413,412,1,0,0,0,413,414,
        1,0,0,0,414,69,1,0,0,0,415,416,7,6,0,0,416,417,5,5,0,0,417,418,7,
        6,0,0,418,71,1,0,0,0,419,420,5,75,0,0,420,425,3,70,35,0,421,422,
        7,7,0,0,422,424,3,70,35,0,423,421,1,0,0,0,424,427,1,0,0,0,425,426,
        1,0,0,0,425,423,1,0,0,0,426,429,1,0,0,0,427,425,1,0,0,0,428,430,
        7,7,0,0,429,428,1,0,0,0,429,430,1,0,0,0,430,431,1,0,0,0,431,432,
        5,76,0,0,432,73,1,0,0,0,433,434,5,51,0,0,434,435,7,5,0,0,435,437,
        3,76,38,0,436,438,3,16,8,0,437,436,1,0,0,0,437,438,1,0,0,0,438,75,
        1,0,0,0,439,443,3,78,39,0,440,443,3,80,40,0,441,443,3,82,41,0,442,
        439,1,0,0,0,442,440,1,0,0,0,442,441,1,0,0,0,443,77,1,0,0,0,444,445,
        5,52,0,0,445,447,7,11,0,0,446,448,5,54,0,0,447,446,1,0,0,0,447,448,
        1,0,0,0,448,449,1,0,0,0,449,450,5,61,0,0,450,451,5,64,0,0,451,452,
        5,56,0,0,452,454,3,42,21,0,453,455,3,16,8,0,454,453,1,0,0,0,454,
        455,1,0,0,0,455,79,1,0,0,0,456,457,5,52,0,0,457,459,7,12,0,0,458,
        460,5,54,0,0,459,458,1,0,0,0,459,460,1,0,0,0,460,461,1,0,0,0,461,
        462,5,62,0,0,462,463,5,64,0,0,463,464,5,56,0,0,464,465,3,42,21,0,
        465,466,5,63,0,0,466,467,5,64,0,0,467,468,5,56,0,0,468,470,3,42,
        21,0,469,471,3,16,8,0,470,469,1,0,0,0,470,471,1,0,0,0,471,81,1,0,
        0,0,472,473,5,52,0,0,473,475,7,5,0,0,474,472,1,0,0,0,474,475,1,0,
        0,0,475,476,1,0,0,0,476,477,3,84,42,0,477,83,1,0,0,0,478,480,5,54,
        0,0,479,478,1,0,0,0,479,480,1,0,0,0,480,482,1,0,0,0,481,483,3,86,
        43,0,482,481,1,0,0,0,483,484,1,0,0,0,484,485,1,0,0,0,484,482,1,0,
        0,0,485,85,1,0,0,0,486,487,5,53,0,0,487,488,7,5,0,0,488,489,5,50,
        0,0,489,492,7,5,0,0,490,491,5,56,0,0,491,493,3,54,27,0,492,490,1,
        0,0,0,492,493,1,0,0,0,493,495,1,0,0,0,494,496,3,16,8,0,495,494,1,
        0,0,0,495,496,1,0,0,0,496,87,1,0,0,0,58,103,109,115,122,131,138,
        140,147,150,156,165,182,190,197,204,211,223,226,233,240,247,254,
        256,258,286,293,300,307,314,316,318,331,336,344,349,357,360,365,
        371,381,386,394,401,410,413,425,429,437,442,447,454,459,470,474,
        479,484,492,495
    ]

class at_krlParser ( Parser ):

    grammarFileName = "at_krl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'||'", "'&&'", "'&'", "'and'", "'|'", 
                     "'or'", "'!'", "'~'", "'not'", "'xor'", "'=='", "'='", 
                     "'eq'", "'>='", "'>'", "'gt'", "'ge'", "'<>'", "'<='", 
                     "'<'", "'lt'", "'le'", "'ne'", "'+'", "'add'", "'-'", 
                     "'sub'", "'**'", "'mul'", "'/'", "'div'", "'%'", "'mod'", 
                     "'^'", "'*'", "'pow'", "':='", "'<-'", "'->'", "';'", 
                     "','", "<INVALID>", "'\\r\\n'", "'\\u0423\\u0412\\u0415\\u0420\\u0415\\u041D\\u041D\\u041E\\u0421\\u0422\\u042C'", 
                     "'\\u0422\\u041E\\u0427\\u041D\\u041E\\u0421\\u0422\\u042C'", 
                     "'\\u041F\\u0420\\u0410\\u0412\\u0418\\u041B\\u041E'", 
                     "'\\u0415\\u0421\\u041B\\u0418'", "'\\u0422\\u041E'", 
                     "'\\u0418\\u041D\\u0410\\u0427\\u0415'", "'\\u0422\\u0418\\u041F'", 
                     "'\\u041E\\u0411\\u042A\\u0415\\u041A\\u0422'", "'\\u0413\\u0420\\u0423\\u041F\\u041F\\u0410'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422\\u042B'", 
                     "'\\u041A\\u041E\\u041C\\u041C\\u0415\\u041D\\u0422\\u0410\\u0420\\u0418\\u0419'", 
                     "'\\u0417\\u041D\\u0410\\u0427\\u0415\\u041D\\u0418\\u0415'", 
                     "'\\u0418\\u041D\\u0422\\u0415\\u0420\\u0412\\u0410\\u041B'", 
                     "'\\u0418\\u043D\\u0442\\u0435\\u0440\\u0432\\u0430\\u043B'", 
                     "'\\u0421\\u041E\\u0411\\u042B\\u0422\\u0418\\u0415'", 
                     "'\\u0421\\u043E\\u0431\\u044B\\u0442\\u0438\\u0435'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u0412\\u043E\\u0437\\u043D'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u041D\\u0430\\u0447'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u041E\\u043A\\u043E\\u043D\\u0447'", 
                     "'\\u0422\\u0418\\u041F \\u041B\\u043E\\u0433\\u0412\\u044B\\u0440'", 
                     "'\\u0421\\u0418\\u041C\\u0412\\u041E\\u041B'", "'\\u0427\\u0418\\u0421\\u041B\\u041E'", 
                     "'\\u041D\\u0415\\u0427\\u0415\\u0422\\u041A\\u0418\\u0419'", 
                     "'\\u041E\\u0422'", "'\\u0414\\u041E'", "'.'", "'('", 
                     "')'", "'['", "']'", "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "ALLEN_SIGN", "NEW_LINE", 
                      "BELIEF", "ACCURACY", "RULE", "IF", "THEN", "ELSE", 
                      "TYPE", "OBJECT", "GROUP", "ATTR", "ATTRS", "COMMENT", 
                      "VALUE", "INTERVAL", "CASED_INTERVAL", "EVENT", "CASED_EVENT", 
                      "OCCURANCE_CONDITION", "OPEN", "CLOSE", "SIMPLE_EXP_TYPE", 
                      "SYM", "NUM", "FUZ", "FROM", "TO", "DOT", "L_BR", 
                      "R_BR", "LS_BR", "RS_BR", "LF_BR", "RF_BR", "LETTER", 
                      "NUMERIC", "ALPHANUMERIC", "ALPHANUMERIC_U", "FRAC", 
                      "WS", "COMM_CHAR", "STRING" ]

    RULE_log_sign = 0
    RULE_comp_sign = 1
    RULE_lowp_math_sign = 2
    RULE_highp_math_sign = 3
    RULE_knowledge_base = 4
    RULE_kb_types = 5
    RULE_kb_classes = 6
    RULE_kb_rules = 7
    RULE_commentary = 8
    RULE_instructions = 9
    RULE_assign_instruction = 10
    RULE_kb_rule = 11
    RULE_kb_rule_instructions = 12
    RULE_kb_rule_condition = 13
    RULE_kb_rule_else_instructions = 14
    RULE_belief = 15
    RULE_accuracy = 16
    RULE_non_factor = 17
    RULE_kb_operation = 18
    RULE_kb_allen_operation = 19
    RULE_simple_operation = 20
    RULE_simple_evaluatable = 21
    RULE_simple_value = 22
    RULE_kb_value = 23
    RULE_ref_path = 24
    RULE_simple_ref = 25
    RULE_kb_reference = 26
    RULE_evaluatable = 27
    RULE_kb_type = 28
    RULE_kb_type_body = 29
    RULE_symbolic_type_body = 30
    RULE_numeric_type_body = 31
    RULE_fuzzy_type_body = 32
    RULE_membersip_function = 33
    RULE_mf_def = 34
    RULE_mf_point = 35
    RULE_mf_body = 36
    RULE_kb_class = 37
    RULE_kb_class_body = 38
    RULE_event_body = 39
    RULE_interval_body = 40
    RULE_object_body = 41
    RULE_attributes = 42
    RULE_attribute = 43

    ruleNames =  [ "log_sign", "comp_sign", "lowp_math_sign", "highp_math_sign", 
                   "knowledge_base", "kb_types", "kb_classes", "kb_rules", 
                   "commentary", "instructions", "assign_instruction", "kb_rule", 
                   "kb_rule_instructions", "kb_rule_condition", "kb_rule_else_instructions", 
                   "belief", "accuracy", "non_factor", "kb_operation", "kb_allen_operation", 
                   "simple_operation", "simple_evaluatable", "simple_value", 
                   "kb_value", "ref_path", "simple_ref", "kb_reference", 
                   "evaluatable", "kb_type", "kb_type_body", "symbolic_type_body", 
                   "numeric_type_body", "fuzzy_type_body", "membersip_function", 
                   "mf_def", "mf_point", "mf_body", "kb_class", "kb_class_body", 
                   "event_body", "interval_body", "object_body", "attributes", 
                   "attribute" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    ALLEN_SIGN=42
    NEW_LINE=43
    BELIEF=44
    ACCURACY=45
    RULE=46
    IF=47
    THEN=48
    ELSE=49
    TYPE=50
    OBJECT=51
    GROUP=52
    ATTR=53
    ATTRS=54
    COMMENT=55
    VALUE=56
    INTERVAL=57
    CASED_INTERVAL=58
    EVENT=59
    CASED_EVENT=60
    OCCURANCE_CONDITION=61
    OPEN=62
    CLOSE=63
    SIMPLE_EXP_TYPE=64
    SYM=65
    NUM=66
    FUZ=67
    FROM=68
    TO=69
    DOT=70
    L_BR=71
    R_BR=72
    LS_BR=73
    RS_BR=74
    LF_BR=75
    RF_BR=76
    LETTER=77
    NUMERIC=78
    ALPHANUMERIC=79
    ALPHANUMERIC_U=80
    FRAC=81
    WS=82
    COMM_CHAR=83
    STRING=84

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Log_signContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return at_krlParser.RULE_log_sign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLog_sign" ):
                listener.enterLog_sign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLog_sign" ):
                listener.exitLog_sign(self)




    def log_sign(self):

        localctx = at_krlParser.Log_signContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_log_sign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 88
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2046) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Comp_signContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return at_krlParser.RULE_comp_sign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComp_sign" ):
                listener.enterComp_sign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComp_sign" ):
                listener.exitComp_sign(self)




    def comp_sign(self):

        localctx = at_krlParser.Comp_signContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_comp_sign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 16775168) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Lowp_math_signContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return at_krlParser.RULE_lowp_math_sign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLowp_math_sign" ):
                listener.enterLowp_math_sign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLowp_math_sign" ):
                listener.exitLowp_math_sign(self)




    def lowp_math_sign(self):

        localctx = at_krlParser.Lowp_math_signContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_lowp_math_sign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 92
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 251658240) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Highp_math_signContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return at_krlParser.RULE_highp_math_sign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHighp_math_sign" ):
                listener.enterHighp_math_sign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHighp_math_sign" ):
                listener.exitHighp_math_sign(self)




    def highp_math_sign(self):

        localctx = at_krlParser.Highp_math_signContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_highp_math_sign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 94
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 137170518016) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Knowledge_baseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_types(self):
            return self.getTypedRuleContext(at_krlParser.Kb_typesContext,0)


        def kb_classes(self):
            return self.getTypedRuleContext(at_krlParser.Kb_classesContext,0)


        def kb_rules(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rulesContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_knowledge_base

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnowledge_base" ):
                listener.enterKnowledge_base(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnowledge_base" ):
                listener.exitKnowledge_base(self)




    def knowledge_base(self):

        localctx = at_krlParser.Knowledge_baseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_knowledge_base)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.kb_types()
            self.state = 97
            self.kb_classes()
            self.state = 98
            self.kb_rules()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_typesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_type(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_typeContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_typeContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_types

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_types" ):
                listener.enterKb_types(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_types" ):
                listener.exitKb_types(self)




    def kb_types(self):

        localctx = at_krlParser.Kb_typesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_kb_types)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,0,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 100
                    self.kb_type() 
                self.state = 105
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_classesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_class(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_classContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_classContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_classes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_classes" ):
                listener.enterKb_classes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_classes" ):
                listener.exitKb_classes(self)




    def kb_classes(self):

        localctx = at_krlParser.Kb_classesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_kb_classes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 109
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,1,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 106
                    self.kb_class() 
                self.state = 111
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,1,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_rule(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_ruleContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_ruleContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rules

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rules" ):
                listener.enterKb_rules(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rules" ):
                listener.exitKb_rules(self)




    def kb_rules(self):

        localctx = at_krlParser.Kb_rulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_kb_rules)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 115
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 112
                    self.kb_rule() 
                self.state = 117
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(at_krlParser.COMMENT, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_commentary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCommentary" ):
                listener.enterCommentary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCommentary" ):
                listener.exitCommentary(self)




    def commentary(self):

        localctx = at_krlParser.CommentaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_commentary)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self.match(at_krlParser.COMMENT)
            self.state = 120 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 119
                    self.matchWildcard()

                else:
                    raise NoViableAltException(self)
                self.state = 122 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assign_instruction(self):
            return self.getTypedRuleContext(at_krlParser.Assign_instructionContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstructions" ):
                listener.enterInstructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstructions" ):
                listener.exitInstructions(self)




    def instructions(self):

        localctx = at_krlParser.InstructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_instructions)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self.assign_instruction()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Assign_instructionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.EvaluatableContext,0)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_assign_instruction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign_instruction" ):
                listener.enterAssign_instruction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign_instruction" ):
                listener.exitAssign_instruction(self)




    def assign_instruction(self):

        localctx = at_krlParser.Assign_instructionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_assign_instruction)
        self._la = 0 # Token type
        try:
            self.state = 140
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 126
                self.ref_path()
                self.state = 127
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 412316864512) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 128
                self.evaluatable()
                self.state = 131
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [44, 45]:
                    self.state = 129
                    self.non_factor()
                    pass
                elif token in [-1, 7, 8, 9, 26, 46, 49, 55, 71, 78, 79, 80, 81, 84]:
                    pass
                else:
                    raise NoViableAltException(self)

                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 133
                self.evaluatable()
                self.state = 134
                self.match(at_krlParser.T__38)
                self.state = 135
                self.ref_path()
                self.state = 138
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [44, 45]:
                    self.state = 136
                    self.non_factor()
                    pass
                elif token in [-1, 7, 8, 9, 26, 46, 49, 55, 71, 78, 79, 80, 81, 84]:
                    pass
                else:
                    raise NoViableAltException(self)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_ruleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RULE(self):
            return self.getToken(at_krlParser.RULE, 0)

        def kb_rule_condition(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_conditionContext,0)


        def kb_rule_instructions(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_instructionsContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def kb_rule_else_instructions(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_else_instructionsContext,0)


        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule" ):
                listener.enterKb_rule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule" ):
                listener.exitKb_rule(self)




    def kb_rule(self):

        localctx = at_krlParser.Kb_ruleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_kb_rule)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            self.match(at_krlParser.RULE)
            self.state = 143
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 144
            self.kb_rule_condition()
            self.state = 145
            self.kb_rule_instructions()
            self.state = 147
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==49:
                self.state = 146
                self.kb_rule_else_instructions()


            self.state = 150
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 149
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_instructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def THEN(self):
            return self.getToken(at_krlParser.THEN, 0)

        def instructions(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.InstructionsContext)
            else:
                return self.getTypedRuleContext(at_krlParser.InstructionsContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_instructions" ):
                listener.enterKb_rule_instructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_instructions" ):
                listener.exitKb_rule_instructions(self)




    def kb_rule_instructions(self):

        localctx = at_krlParser.Kb_rule_instructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_kb_rule_instructions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 152
            self.match(at_krlParser.THEN)
            self.state = 154 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 153
                self.instructions()
                self.state = 156 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 67109760) != 0) or ((((_la - 71)) & ~0x3f) == 0 and ((1 << (_la - 71)) & 10113) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_conditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(at_krlParser.IF, 0)

        def kb_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_condition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_condition" ):
                listener.enterKb_rule_condition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_condition" ):
                listener.exitKb_rule_condition(self)




    def kb_rule_condition(self):

        localctx = at_krlParser.Kb_rule_conditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_kb_rule_condition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(at_krlParser.IF)
            self.state = 159
            self.kb_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_else_instructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELSE(self):
            return self.getToken(at_krlParser.ELSE, 0)

        def instructions(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.InstructionsContext)
            else:
                return self.getTypedRuleContext(at_krlParser.InstructionsContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_else_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_else_instructions" ):
                listener.enterKb_rule_else_instructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_else_instructions" ):
                listener.exitKb_rule_else_instructions(self)




    def kb_rule_else_instructions(self):

        localctx = at_krlParser.Kb_rule_else_instructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_kb_rule_else_instructions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 161
            self.match(at_krlParser.ELSE)
            self.state = 163 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 162
                self.instructions()
                self.state = 165 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 67109760) != 0) or ((((_la - 71)) & ~0x3f) == 0 and ((1 << (_la - 71)) & 10113) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BeliefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BELIEF(self):
            return self.getToken(at_krlParser.BELIEF, 0)

        def LS_BR(self):
            return self.getToken(at_krlParser.LS_BR, 0)

        def RS_BR(self):
            return self.getToken(at_krlParser.RS_BR, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_belief

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBelief" ):
                listener.enterBelief(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBelief" ):
                listener.exitBelief(self)




    def belief(self):

        localctx = at_krlParser.BeliefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_belief)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 167
            self.match(at_krlParser.BELIEF)
            self.state = 168
            self.match(at_krlParser.LS_BR)
            self.state = 169
            _la = self._input.LA(1)
            if not(_la==78 or _la==81):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 170
            _la = self._input.LA(1)
            if not(_la==40 or _la==41):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 171
            _la = self._input.LA(1)
            if not(_la==78 or _la==81):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 172
            self.match(at_krlParser.RS_BR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AccuracyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACCURACY(self):
            return self.getToken(at_krlParser.ACCURACY, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def FRAC(self):
            return self.getToken(at_krlParser.FRAC, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_accuracy

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAccuracy" ):
                listener.enterAccuracy(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAccuracy" ):
                listener.exitAccuracy(self)




    def accuracy(self):

        localctx = at_krlParser.AccuracyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_accuracy)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.match(at_krlParser.ACCURACY)
            self.state = 175
            _la = self._input.LA(1)
            if not(_la==78 or _la==81):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Non_factorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def belief(self):
            return self.getTypedRuleContext(at_krlParser.BeliefContext,0)


        def accuracy(self):
            return self.getTypedRuleContext(at_krlParser.AccuracyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_non_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNon_factor" ):
                listener.enterNon_factor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNon_factor" ):
                listener.exitNon_factor(self)




    def non_factor(self):

        localctx = at_krlParser.Non_factorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_non_factor)
        try:
            self.state = 182
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 177
                self.belief()
                self.state = 178
                self.accuracy()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 180
                self.belief()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 181
                self.accuracy()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Ref_pathContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Ref_pathContext,i)


        def kb_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_valueContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_valueContext,i)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def kb_reference(self):
            return self.getTypedRuleContext(at_krlParser.Kb_referenceContext,0)


        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def kb_operation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_operationContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_operationContext,i)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def kb_allen_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_allen_operationContext,0)


        def highp_math_sign(self):
            return self.getTypedRuleContext(at_krlParser.Highp_math_signContext,0)


        def lowp_math_sign(self):
            return self.getTypedRuleContext(at_krlParser.Lowp_math_signContext,0)


        def comp_sign(self):
            return self.getTypedRuleContext(at_krlParser.Comp_signContext,0)


        def log_sign(self):
            return self.getTypedRuleContext(at_krlParser.Log_signContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_operation" ):
                listener.enterKb_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_operation" ):
                listener.exitKb_operation(self)



    def kb_operation(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = at_krlParser.Kb_operationContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 36
        self.enterRecursionRule(localctx, 36, self.RULE_kb_operation, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 226
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 185
                self.ref_path()
                self.state = 186
                self.match(at_krlParser.T__11)
                self.state = 187
                self.kb_value()
                self.state = 190
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
                if la_ == 1:
                    self.state = 188
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 2:
                self.state = 192
                self.kb_value()
                self.state = 193
                self.match(at_krlParser.T__11)
                self.state = 194
                self.ref_path()
                self.state = 197
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
                if la_ == 1:
                    self.state = 195
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 3:
                self.state = 199
                self.ref_path()
                self.state = 200
                self.match(at_krlParser.T__11)
                self.state = 201
                self.ref_path()
                self.state = 204
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
                if la_ == 1:
                    self.state = 202
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 4:
                self.state = 206
                self.kb_value()
                self.state = 207
                self.match(at_krlParser.T__11)
                self.state = 208
                self.kb_value()
                self.state = 211
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
                if la_ == 1:
                    self.state = 209
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 5:
                self.state = 213
                self.kb_reference()
                pass

            elif la_ == 6:
                self.state = 214
                self.kb_value()
                pass

            elif la_ == 7:
                self.state = 215
                self.match(at_krlParser.L_BR)
                self.state = 216
                self.kb_operation(0)
                self.state = 217
                self.match(at_krlParser.R_BR)
                pass

            elif la_ == 8:
                self.state = 219
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 67109760) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 220
                self.kb_operation(0)
                self.state = 223
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
                if la_ == 1:
                    self.state = 221
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 9:
                self.state = 225
                self.kb_allen_operation()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 258
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 256
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
                    if la_ == 1:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 228
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 229
                        self.highp_math_sign()
                        self.state = 230
                        self.kb_operation(0)
                        self.state = 233
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                        if la_ == 1:
                            self.state = 231
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 2:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 235
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 236
                        self.lowp_math_sign()
                        self.state = 237
                        self.kb_operation(0)
                        self.state = 240
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
                        if la_ == 1:
                            self.state = 238
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 3:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 242
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 243
                        self.comp_sign()
                        self.state = 244
                        self.kb_operation(0)
                        self.state = 247
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
                        if la_ == 1:
                            self.state = 245
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 4:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 249
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 250
                        self.log_sign()
                        self.state = 251
                        self.kb_operation(0)
                        self.state = 254
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
                        if la_ == 1:
                            self.state = 252
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

             
                self.state = 260
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Kb_allen_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALLEN_SIGN(self):
            return self.getToken(at_krlParser.ALLEN_SIGN, 0)

        def ALPHANUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC, i)

        def ALPHANUMERIC_U(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC_U)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC_U, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_kb_allen_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_allen_operation" ):
                listener.enterKb_allen_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_allen_operation" ):
                listener.exitKb_allen_operation(self)




    def kb_allen_operation(self):

        localctx = at_krlParser.Kb_allen_operationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_kb_allen_operation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 261
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 262
            self.match(at_krlParser.ALLEN_SIGN)
            self.state = 263
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simple_value(self):
            return self.getTypedRuleContext(at_krlParser.Simple_valueContext,0)


        def ref_path(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Ref_pathContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Ref_pathContext,i)


        def simple_ref(self):
            return self.getTypedRuleContext(at_krlParser.Simple_refContext,0)


        def simple_operation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Simple_operationContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Simple_operationContext,i)


        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def highp_math_sign(self):
            return self.getTypedRuleContext(at_krlParser.Highp_math_signContext,0)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def lowp_math_sign(self):
            return self.getTypedRuleContext(at_krlParser.Lowp_math_signContext,0)


        def comp_sign(self):
            return self.getTypedRuleContext(at_krlParser.Comp_signContext,0)


        def log_sign(self):
            return self.getTypedRuleContext(at_krlParser.Log_signContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_simple_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_operation" ):
                listener.enterSimple_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_operation" ):
                listener.exitSimple_operation(self)



    def simple_operation(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = at_krlParser.Simple_operationContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 40
        self.enterRecursionRule(localctx, 40, self.RULE_simple_operation, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 286
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.state = 266
                self.simple_value()
                self.state = 267
                self.match(at_krlParser.T__11)
                self.state = 268
                self.ref_path()
                pass

            elif la_ == 2:
                self.state = 270
                self.ref_path()
                self.state = 271
                self.match(at_krlParser.T__11)
                self.state = 272
                self.ref_path()
                pass

            elif la_ == 3:
                self.state = 274
                self.ref_path()
                self.state = 275
                self.match(at_krlParser.T__11)
                self.state = 276
                self.simple_value()
                pass

            elif la_ == 4:
                self.state = 278
                self.simple_ref()
                pass

            elif la_ == 5:
                self.state = 279
                self.simple_value()
                pass

            elif la_ == 6:
                self.state = 280
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 896) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 281
                self.simple_operation(6)
                pass

            elif la_ == 7:
                self.state = 282
                self.match(at_krlParser.L_BR)
                self.state = 283
                self.simple_operation(0)
                self.state = 284
                self.match(at_krlParser.R_BR)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 318
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,30,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 316
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
                    if la_ == 1:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 288
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 289
                        self.highp_math_sign()
                        self.state = 290
                        self.simple_operation(0)
                        self.state = 293
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
                        if la_ == 1:
                            self.state = 291
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 2:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 295
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 296
                        self.lowp_math_sign()
                        self.state = 297
                        self.simple_operation(0)
                        self.state = 300
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
                        if la_ == 1:
                            self.state = 298
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 3:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 302
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 303
                        self.comp_sign()
                        self.state = 304
                        self.simple_operation(0)
                        self.state = 307
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
                        if la_ == 1:
                            self.state = 305
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 4:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 309
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 310
                        self.log_sign()
                        self.state = 311
                        self.simple_operation(0)
                        self.state = 314
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
                        if la_ == 1:
                            self.state = 312
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

             
                self.state = 320
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Simple_evaluatableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simple_operation(self):
            return self.getTypedRuleContext(at_krlParser.Simple_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_simple_evaluatable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_evaluatable" ):
                listener.enterSimple_evaluatable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_evaluatable" ):
                listener.exitSimple_evaluatable(self)




    def simple_evaluatable(self):

        localctx = at_krlParser.Simple_evaluatableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_simple_evaluatable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 321
            self.simple_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(at_krlParser.STRING, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def FRAC(self):
            return self.getToken(at_krlParser.FRAC, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_simple_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_value" ):
                listener.enterSimple_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_value" ):
                listener.exitSimple_value(self)




    def simple_value(self):

        localctx = at_krlParser.Simple_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_simple_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 323
            _la = self._input.LA(1)
            if not(((((_la - 78)) & ~0x3f) == 0 and ((1 << (_la - 78)) & 73) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def kb_value(self):
            return self.getTypedRuleContext(at_krlParser.Kb_valueContext,0)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def simple_value(self):
            return self.getTypedRuleContext(at_krlParser.Simple_valueContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_value" ):
                listener.enterKb_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_value" ):
                listener.exitKb_value(self)




    def kb_value(self):

        localctx = at_krlParser.Kb_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_kb_value)
        try:
            self.state = 331
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [71]:
                self.enterOuterAlt(localctx, 1)
                self.state = 325
                self.match(at_krlParser.L_BR)
                self.state = 326
                self.kb_value()
                self.state = 327
                self.non_factor()
                self.state = 328
                self.match(at_krlParser.R_BR)
                pass
            elif token in [78, 81, 84]:
                self.enterOuterAlt(localctx, 2)
                self.state = 330
                self.simple_value()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ref_pathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def DOT(self):
            return self.getToken(at_krlParser.DOT, 0)

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_ref_path

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRef_path" ):
                listener.enterRef_path(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRef_path" ):
                listener.exitRef_path(self)




    def ref_path(self):

        localctx = at_krlParser.Ref_pathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_ref_path)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 333
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 336
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.state = 334
                self.match(at_krlParser.DOT)
                self.state = 335
                self.ref_path()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_refContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_simple_ref

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_ref" ):
                listener.enterSimple_ref(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_ref" ):
                listener.exitSimple_ref(self)




    def simple_ref(self):

        localctx = at_krlParser.Simple_refContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_simple_ref)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 338
            self.ref_path()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_referenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def simple_ref(self):
            return self.getTypedRuleContext(at_krlParser.Simple_refContext,0)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_reference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_reference" ):
                listener.enterKb_reference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_reference" ):
                listener.exitKb_reference(self)




    def kb_reference(self):

        localctx = at_krlParser.Kb_referenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_kb_reference)
        try:
            self.state = 349
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [71]:
                self.enterOuterAlt(localctx, 1)
                self.state = 340
                self.match(at_krlParser.L_BR)
                self.state = 341
                self.simple_ref()
                self.state = 344
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [44, 45]:
                    self.state = 342
                    self.non_factor()
                    pass
                elif token in [72]:
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 346
                self.match(at_krlParser.R_BR)
                pass
            elif token in [79, 80]:
                self.enterOuterAlt(localctx, 2)
                self.state = 348
                self.simple_ref()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EvaluatableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_evaluatable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvaluatable" ):
                listener.enterEvaluatable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvaluatable" ):
                listener.exitEvaluatable(self)




    def evaluatable(self):

        localctx = at_krlParser.EvaluatableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_evaluatable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 351
            self.kb_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(at_krlParser.TYPE, 0)

        def kb_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Kb_type_bodyContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_type" ):
                listener.enterKb_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_type" ):
                listener.exitKb_type(self)




    def kb_type(self):

        localctx = at_krlParser.Kb_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_kb_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 353
            self.match(at_krlParser.TYPE)
            self.state = 354
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 355
            self.kb_type_body()
            self.state = 357
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 356
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fuzzy_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Fuzzy_type_bodyContext,0)


        def symbolic_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Symbolic_type_bodyContext,0)


        def numeric_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Numeric_type_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_type_body" ):
                listener.enterKb_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_type_body" ):
                listener.exitKb_type_body(self)




    def kb_type_body(self):

        localctx = at_krlParser.Kb_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_kb_type_body)
        self._la = 0 # Token type
        try:
            self.state = 365
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 360
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==65:
                    self.state = 359
                    self.symbolic_type_body()


                self.state = 362
                self.fuzzy_type_body()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 363
                self.symbolic_type_body()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 364
                self.numeric_type_body()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Symbolic_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SYM(self):
            return self.getToken(at_krlParser.SYM, 0)

        def STRING(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.STRING)
            else:
                return self.getToken(at_krlParser.STRING, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_symbolic_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSymbolic_type_body" ):
                listener.enterSymbolic_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSymbolic_type_body" ):
                listener.exitSymbolic_type_body(self)




    def symbolic_type_body(self):

        localctx = at_krlParser.Symbolic_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_symbolic_type_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 367
            self.match(at_krlParser.SYM)
            self.state = 369 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 368
                    self.match(at_krlParser.STRING)

                else:
                    raise NoViableAltException(self)
                self.state = 371 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Numeric_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUM(self):
            return self.getToken(at_krlParser.NUM, 0)

        def FROM(self):
            return self.getToken(at_krlParser.FROM, 0)

        def TO(self):
            return self.getToken(at_krlParser.TO, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_numeric_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumeric_type_body" ):
                listener.enterNumeric_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumeric_type_body" ):
                listener.exitNumeric_type_body(self)




    def numeric_type_body(self):

        localctx = at_krlParser.Numeric_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_numeric_type_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 373
            self.match(at_krlParser.NUM)
            self.state = 374
            self.match(at_krlParser.FROM)
            self.state = 381
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
            if la_ == 1:
                self.state = 375
                self.match(at_krlParser.NUMERIC)
                pass

            elif la_ == 2:
                self.state = 376
                self.match(at_krlParser.FRAC)
                pass

            elif la_ == 3:
                self.state = 377
                self.match(at_krlParser.T__25)
                self.state = 378
                self.match(at_krlParser.NUMERIC)
                pass

            elif la_ == 4:
                self.state = 379
                self.match(at_krlParser.T__25)
                self.state = 380
                self.match(at_krlParser.FRAC)
                pass


            self.state = 383
            self.match(at_krlParser.TO)
            self.state = 386
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,40,self._ctx)
            if la_ == 1:
                self.state = 384
                self.match(at_krlParser.T__25)
                pass

            elif la_ == 2:
                pass


            self.state = 394
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,41,self._ctx)
            if la_ == 1:
                self.state = 388
                self.match(at_krlParser.NUMERIC)
                pass

            elif la_ == 2:
                self.state = 389
                self.match(at_krlParser.FRAC)
                pass

            elif la_ == 3:
                self.state = 390
                self.match(at_krlParser.T__25)
                self.state = 391
                self.match(at_krlParser.NUMERIC)
                pass

            elif la_ == 4:
                self.state = 392
                self.match(at_krlParser.T__25)
                self.state = 393
                self.match(at_krlParser.FRAC)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fuzzy_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUZ(self):
            return self.getToken(at_krlParser.FUZ, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def membersip_function(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Membersip_functionContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Membersip_functionContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_fuzzy_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuzzy_type_body" ):
                listener.enterFuzzy_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuzzy_type_body" ):
                listener.exitFuzzy_type_body(self)




    def fuzzy_type_body(self):

        localctx = at_krlParser.Fuzzy_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_fuzzy_type_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 396
            self.match(at_krlParser.FUZ)
            self.state = 397
            self.match(at_krlParser.NUMERIC)
            self.state = 399 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 398
                    self.membersip_function()

                else:
                    raise NoViableAltException(self)
                self.state = 401 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,42,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Membersip_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mf_def(self):
            return self.getTypedRuleContext(at_krlParser.Mf_defContext,0)


        def mf_body(self):
            return self.getTypedRuleContext(at_krlParser.Mf_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_membersip_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMembersip_function" ):
                listener.enterMembersip_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMembersip_function" ):
                listener.exitMembersip_function(self)




    def membersip_function(self):

        localctx = at_krlParser.Membersip_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_membersip_function)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 403
            self.mf_def()
            self.state = 404
            self.mf_body()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(at_krlParser.STRING, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_mf_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_def" ):
                listener.enterMf_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_def" ):
                listener.exitMf_def(self)




    def mf_def(self):

        localctx = at_krlParser.Mf_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_mf_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 406
            self.match(at_krlParser.STRING)
            self.state = 407
            _la = self._input.LA(1)
            if not(_la==78 or _la==81):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 408
            _la = self._input.LA(1)
            if not(_la==78 or _la==81):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 410
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==78:
                self.state = 409
                self.match(at_krlParser.NUMERIC)


            self.state = 413
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==12:
                self.state = 412
                self.match(at_krlParser.T__11)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_pointContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_mf_point

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_point" ):
                listener.enterMf_point(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_point" ):
                listener.exitMf_point(self)




    def mf_point(self):

        localctx = at_krlParser.Mf_pointContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_mf_point)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 415
            _la = self._input.LA(1)
            if not(_la==78 or _la==81):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 416
            self.match(at_krlParser.T__4)
            self.state = 417
            _la = self._input.LA(1)
            if not(_la==78 or _la==81):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LF_BR(self):
            return self.getToken(at_krlParser.LF_BR, 0)

        def RF_BR(self):
            return self.getToken(at_krlParser.RF_BR, 0)

        def mf_point(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Mf_pointContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Mf_pointContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_mf_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_body" ):
                listener.enterMf_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_body" ):
                listener.exitMf_body(self)




    def mf_body(self):

        localctx = at_krlParser.Mf_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_mf_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 419
            self.match(at_krlParser.LF_BR)

            self.state = 420
            self.mf_point()
            self.state = 425
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,45,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 421
                    _la = self._input.LA(1)
                    if not(_la==40 or _la==41):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 422
                    self.mf_point() 
                self.state = 427
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,45,self._ctx)

            self.state = 429
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==40 or _la==41:
                self.state = 428
                _la = self._input.LA(1)
                if not(_la==40 or _la==41):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 431
            self.match(at_krlParser.RF_BR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_classContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OBJECT(self):
            return self.getToken(at_krlParser.OBJECT, 0)

        def kb_class_body(self):
            return self.getTypedRuleContext(at_krlParser.Kb_class_bodyContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_class

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_class" ):
                listener.enterKb_class(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_class" ):
                listener.exitKb_class(self)




    def kb_class(self):

        localctx = at_krlParser.Kb_classContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_kb_class)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 433
            self.match(at_krlParser.OBJECT)
            self.state = 434
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 435
            self.kb_class_body()
            self.state = 437
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 436
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_class_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def event_body(self):
            return self.getTypedRuleContext(at_krlParser.Event_bodyContext,0)


        def interval_body(self):
            return self.getTypedRuleContext(at_krlParser.Interval_bodyContext,0)


        def object_body(self):
            return self.getTypedRuleContext(at_krlParser.Object_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_class_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_class_body" ):
                listener.enterKb_class_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_class_body" ):
                listener.exitKb_class_body(self)




    def kb_class_body(self):

        localctx = at_krlParser.Kb_class_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_kb_class_body)
        try:
            self.state = 442
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,48,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 439
                self.event_body()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 440
                self.interval_body()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 441
                self.object_body()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Event_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def OCCURANCE_CONDITION(self):
            return self.getToken(at_krlParser.OCCURANCE_CONDITION, 0)

        def SIMPLE_EXP_TYPE(self):
            return self.getToken(at_krlParser.SIMPLE_EXP_TYPE, 0)

        def VALUE(self):
            return self.getToken(at_krlParser.VALUE, 0)

        def simple_evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.Simple_evaluatableContext,0)


        def EVENT(self):
            return self.getToken(at_krlParser.EVENT, 0)

        def CASED_EVENT(self):
            return self.getToken(at_krlParser.CASED_EVENT, 0)

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_event_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvent_body" ):
                listener.enterEvent_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvent_body" ):
                listener.exitEvent_body(self)




    def event_body(self):

        localctx = at_krlParser.Event_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_event_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 444
            self.match(at_krlParser.GROUP)
            self.state = 445
            _la = self._input.LA(1)
            if not(_la==59 or _la==60):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 447
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==54:
                self.state = 446
                self.match(at_krlParser.ATTRS)


            self.state = 449
            self.match(at_krlParser.OCCURANCE_CONDITION)
            self.state = 450
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 451
            self.match(at_krlParser.VALUE)
            self.state = 452
            self.simple_evaluatable()
            self.state = 454
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,50,self._ctx)
            if la_ == 1:
                self.state = 453
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Interval_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def OPEN(self):
            return self.getToken(at_krlParser.OPEN, 0)

        def SIMPLE_EXP_TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.SIMPLE_EXP_TYPE)
            else:
                return self.getToken(at_krlParser.SIMPLE_EXP_TYPE, i)

        def VALUE(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.VALUE)
            else:
                return self.getToken(at_krlParser.VALUE, i)

        def simple_evaluatable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Simple_evaluatableContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Simple_evaluatableContext,i)


        def CLOSE(self):
            return self.getToken(at_krlParser.CLOSE, 0)

        def INTERVAL(self):
            return self.getToken(at_krlParser.INTERVAL, 0)

        def CASED_INTERVAL(self):
            return self.getToken(at_krlParser.CASED_INTERVAL, 0)

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_interval_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInterval_body" ):
                listener.enterInterval_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInterval_body" ):
                listener.exitInterval_body(self)




    def interval_body(self):

        localctx = at_krlParser.Interval_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_interval_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 456
            self.match(at_krlParser.GROUP)
            self.state = 457
            _la = self._input.LA(1)
            if not(_la==57 or _la==58):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 459
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==54:
                self.state = 458
                self.match(at_krlParser.ATTRS)


            self.state = 461
            self.match(at_krlParser.OPEN)
            self.state = 462
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 463
            self.match(at_krlParser.VALUE)
            self.state = 464
            self.simple_evaluatable()
            self.state = 465
            self.match(at_krlParser.CLOSE)
            self.state = 466
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 467
            self.match(at_krlParser.VALUE)
            self.state = 468
            self.simple_evaluatable()
            self.state = 470
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,52,self._ctx)
            if la_ == 1:
                self.state = 469
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Object_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def attributes(self):
            return self.getTypedRuleContext(at_krlParser.AttributesContext,0)


        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_object_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObject_body" ):
                listener.enterObject_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObject_body" ):
                listener.exitObject_body(self)




    def object_body(self):

        localctx = at_krlParser.Object_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_object_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 474
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==52:
                self.state = 472
                self.match(at_krlParser.GROUP)
                self.state = 473
                _la = self._input.LA(1)
                if not(_la==79 or _la==80):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 476
            self.attributes()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def attribute(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.AttributeContext)
            else:
                return self.getTypedRuleContext(at_krlParser.AttributeContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_attributes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributes" ):
                listener.enterAttributes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributes" ):
                listener.exitAttributes(self)




    def attributes(self):

        localctx = at_krlParser.AttributesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_attributes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 479
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==54:
                self.state = 478
                self.match(at_krlParser.ATTRS)


            self.state = 482 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 481
                    self.attribute()

                else:
                    raise NoViableAltException(self)
                self.state = 484 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,55,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTR(self):
            return self.getToken(at_krlParser.ATTR, 0)

        def TYPE(self):
            return self.getToken(at_krlParser.TYPE, 0)

        def ALPHANUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC, i)

        def ALPHANUMERIC_U(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC_U)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC_U, i)

        def VALUE(self):
            return self.getToken(at_krlParser.VALUE, 0)

        def evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.EvaluatableContext,0)


        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_attribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttribute" ):
                listener.enterAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttribute" ):
                listener.exitAttribute(self)




    def attribute(self):

        localctx = at_krlParser.AttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_attribute)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 486
            self.match(at_krlParser.ATTR)
            self.state = 487
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 488
            self.match(at_krlParser.TYPE)
            self.state = 489
            _la = self._input.LA(1)
            if not(_la==79 or _la==80):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 492
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==56:
                self.state = 490
                self.match(at_krlParser.VALUE)
                self.state = 491
                self.evaluatable()


            self.state = 495
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,57,self._ctx)
            if la_ == 1:
                self.state = 494
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[18] = self.kb_operation_sempred
        self._predicates[20] = self.simple_operation_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def kb_operation_sempred(self, localctx:Kb_operationContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 2)
         

    def simple_operation_sempred(self, localctx:Simple_operationContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 2)
         




